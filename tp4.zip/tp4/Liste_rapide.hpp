#include "Liste.hpp"
  
#ifndef _lister_
#define _lister_

class lister
{
int size_p;
int nbe;
liste *princ;
liste *second;
int compare;
int affectation;

public:
lister(int size);
~lister();

int getcompare(){return compare;}
int getaffect(){return affectation;}

void afficher();
bool chercher(int n);
bool ajoute(int n);
bool supprimer(int n);
};
#endif

