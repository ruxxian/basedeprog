#include "Liste_rapide.hpp"
#include <iostream>
#include <fstream>

using namespace std;

int main(int argc, char* argv[])
{
    char c;
    int x;
    // Tester pour différentes tailles de liste
    for (int i = 10; i < 60; i += 10)
    {

        lister *Lr = new lister(i);
        liste *L = new liste();

        ifstream fichier(argv[1]);
        while (fichier >> c >> x)
        {
            if (c == 'r')
            {
                Lr->chercher(x);
                L->chercher(x);
            }
            else if (c == 's')
            {
                Lr->supprimer(x);
                L->supprimer(x);
            }
            else if (c == 'i')
            {
                Lr->ajoute(x);
                L->ajoute(x);
            }
        }

        // Récupérer les compteurs
        int compR = Lr->getcompare();
        int affectR = Lr->getaffect();

        int comp = L->getcompare();
        int affect = L->getaffect();
        // Afficher les résultats
        cout << "lister rapide taille " << i << ":" << endl;
        cout << "comparaison: " << compR << endl;
        cout << "affectation: " << affectR << endl;
        cout << endl;

        cout << "lister normale taille :" << endl;
        cout << "comparaison: " << comp << endl;
        cout << "affectation: " << affect << endl;

        if (compR < comp)
        {
            cout << "la liste rapide est plus efficace sur les comparaisons" << endl;
        }
        else
        {
            cout << "la liste normale est plus efficace pour les comparaisons" << endl;
        }

        if (affectR < affect)
        {
            cout << "la liste rapide est plus efficace sur les affectations" << endl;
        }
        else
        {
            cout << "la liste normale est plus efficace pour les affectations" << endl;
        }
        cout <<"------------------------------------------------------------------"<< endl;

        // Libérer la mémoire
        delete Lr;
        delete L;
    }

    return 0;
}