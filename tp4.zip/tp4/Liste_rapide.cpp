#include "Liste_rapide.hpp"
#include <iostream>
lister::lister(int size)
{
size_p=size;
nbe=0;
princ = new liste();
second = new liste();
compare=0;
affectation=0;
}   

lister::~lister()
{ 
	delete princ;
	delete second;
}

bool lister::supprimer(int x)
{
    // Variables pour stocker les résultats de la recherche
    maillon* courant = nullptr;
    maillon* precedent = nullptr;
    maillon* avant_precedent = nullptr;
    affectation += 3;
    // Rechercher l'élément dans la liste principale
    (*princ).outils_pour_Recherche(x, courant, precedent, avant_precedent);

    if (courant)
    {
        // Si l'élément est trouvé dans la liste principale
        if (precedent == nullptr) {
            // Cas où l'élément est en tête de la liste principale
            princ->tete = courant->suiv;
        } else {
            // Cas où l'élément est au milieu ou à la fin de la liste principale
            precedent->suiv = courant->suiv;
        }
        princ->affectation++;
        delete courant; // Libérer la mémoire
        nbe--; // Décrémenter le nombre d'éléments dans la liste principale
        compare = princ->compare + second->compare;
        affectation = princ->affectation + second->affectation;
        return true; // L'élément a été supprimé
    }
    else
    {
        // Si l'élément n'est pas trouvé dans la liste principale, rechercher dans la liste secondaire
        (*second).outils_pour_Recherche(x, courant, precedent, avant_precedent);

        if (courant) {
            // Si l'élément est trouvé dans la liste secondaire

            if (precedent == nullptr) {
                // Cas où l'élément est en tête de la liste secondaire
                second->tete = courant->suiv;
            } else {
                // Cas où l'élément est au milieu ou à la fin de la liste secondaire
                precedent->suiv = courant->suiv;
            }
            second->affectation++;
            delete courant; // Libérer la mémoire
            compare = princ->compare + second->compare;
            affectation = princ->affectation + second->affectation;
            return true; // L'élément a été supprimé
        }
    }
    // Si l'élément n'a pas été trouvé dans les deux listes
    return false;
}

bool lister::chercher(int n) {
    maillon *c = nullptr, *pr = nullptr, *apr = nullptr;
    bool trouver = false;
    affectation += 3; // Initialisation des pointeurs

    // Rechercher dans la liste principale
    princ->outils_pour_Recherche(n, c, pr, apr);

    if (c != nullptr) {
        // L'élément est trouvé dans la liste principale
        trouver = true;

        if (pr != nullptr) {
            // Déplacer l'élément vers l'avant dans la liste principale
            if (apr) {
                apr->suiv = c;
                princ->affectation++;
            }
            pr->suiv = c->suiv;
            c->suiv = princ->tete;
            princ->tete = c;
            princ->affectation += 3;
        }
    } else {
        // Rechercher dans la liste secondaire
        maillon *cs = nullptr, *prs = nullptr, *aprs = nullptr;
        affectation += 3; // Initialisation des pointeurs
        second->outils_pour_Recherche(n, cs, prs, aprs);

        if (cs != nullptr) {
            // L'élément est trouvé dans la liste secondaire
            trouver = true;

            if (nbe < size_p) {
                // Il y a de la place dans la liste principale
                if (prs != nullptr) {
                    prs->suiv = cs->suiv; // Retirer cs de la liste secondaire
                } else {
                    second->tete = cs->suiv; // cs était en tête de la liste secondaire
                }
                second->affectation++;

                // Ajouter cs à la tête de la liste principale
                cs->suiv = princ->tete;
                princ->tete = cs;
                princ->affectation += 2;
                nbe++;
            } else if (nbe == size_p) {
                // Détacher le dernier élément de la liste principale et l'ajouter à la liste secondaire
                maillon *dernier = princ->tete;
                maillon *avant_dernier = nullptr;

                while (dernier->suiv != nullptr) {
                    avant_dernier = dernier;
                    dernier = dernier->suiv;
                    princ->affectation += 2;
                }

                if (avant_dernier != nullptr) {
                    avant_dernier->suiv = nullptr; // Détacher le dernier élément
                } else {
                    princ->tete = nullptr; // La liste principale est maintenant vide
                }
                princ->affectation++;

                // Ajouter le dernier élément à la tête de la liste secondaire
                dernier->suiv = second->tete;
                second->tete = dernier;
                second->affectation += 2;

                // Ajouter cs à la tête de la liste principale
                cs->suiv = princ->tete;
                princ->tete = cs;
                princ->affectation += 2;
            }
        }
    }

    // Si la liste principale dépasse sa capacité, déplacer le dernier élément vers la liste secondaire
    if (nbe > size_p) {
        maillon *dernier = princ->tete;
        maillon *avant_dernier = nullptr;

        while (dernier->suiv != nullptr) {
            avant_dernier = dernier;
            dernier = dernier->suiv;
            princ->affectation += 2;
        }

        if (avant_dernier != nullptr) {
            avant_dernier->suiv = nullptr; // Détacher le dernier élément
        } else {
            princ->tete = nullptr; // La liste principale est maintenant vide
        }
        princ->affectation++;

        // Ajouter le dernier élément à la tête de la liste secondaire
        dernier->suiv = second->tete;
        second->tete = dernier;
        second->affectation += 2;

        nbe--;
    }

    // Ajouter les éléments de la liste secondaire à la liste principale tant qu'il reste de la place
    while (nbe < size_p && second->tete != nullptr) {
        maillon *element = second->tete;
        second->tete = element->suiv;
        second->affectation++;

        element->suiv = princ->tete;
        princ->tete = element;
        princ->affectation += 2;

        nbe++;
    }

    // Mettre à jour les compteurs globaux
    compare = princ->compare + second->compare;
    affectation = princ->affectation + second->affectation;

    return trouver;
}

bool lister::ajoute(int x)
{
    if(chercher(x))return false;
    maillon* nouveau = new maillon(x);
    nouveau->suiv = princ->tete;
    princ->tete = nouveau;
    affectation+=3;
    nbe++;
    return true;
}