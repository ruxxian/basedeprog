#include "expression.hpp"
#include "cPile.hpp"
#include "Pile.hpp"
#include <sstream>
#include <iostream>
#include <string>
using namespace std;

double expression::evaluer(string s1)
{
	istringstream s(s1);
	string h;
    Pile chaine;
	while(s >> h)
	{ 
		if( h!= "+" && h != "-" && h != "*" && h!="/" && h!="(" && h!=")" ){
			double d = stod(h);
			//empiler l"opérande
            chaine.empiler(d);
		}
		else if(chaine.nbe>=2){
			//depiler les deux dernier et appliquer l"opérateur
			double a = chaine.depiler();
			double b = chaine.depiler();
			
			if(h == "+")
			{
				chaine.empiler(a+b);
			}
			else if(h == "-")
			{
				chaine.empiler(a-b);
			}
			else if(h == "*")
			{
				chaine.empiler(a*b);
			}
			else if(h == "/")
			{
				chaine.empiler(a/b);
			}
		}
	}
	return(chaine.depiler());
}


int priorite(char op) {
    if (op == '+' || op == '-') return 1;
    if (op == '*' || op == '/') return 2;
    if (op == '^') return 3;
    return 0;
}

bool associatifGauche(char op) {
    return op != '^';
}

string expression::suffixee(string exp) {
    cPile pile;
    string sortie;
    istringstream iss(exp);
    string token;
    
    while (iss >> token) {
        if (token != "+" && token != "-" && token != "*" && token != "/" && token != "(" && token != ")") {
            sortie += token + " ";
        }
        else if (token == "(") {
            pile.empiler('(');
        }
        else if (token == ")") {
            while (!pile.vide() && pile.sommet() != '(') {
                sortie += pile.depiler();
                sortie += " ";
            }
            if (pile.vide()) throw runtime_error("Mismatched parentheses");
            pile.depiler(); // enlever '('
        }
        else { // opérateur
            char op = token[0];
            while (!pile.vide() && pile.sommet() != '(' &&
                  ((associatifGauche(op) && priorite(op) <= priorite(pile.sommet())) ||
                   (!associatifGauche(op) && priorite(op) < priorite(pile.sommet())))) {
                sortie += pile.depiler();
                sortie += " ";
            }
            pile.empiler(op);
        }
    }

    while (!pile.vide()) {
        if (pile.sommet() == '(') throw runtime_error("Mismatched parentheses");
        sortie += pile.depiler();
        sortie += " ";
    }

    if (!sortie.empty() && sortie.back() == ' ') sortie.pop_back();

    return sortie;
}


double expression::evaluerinfixee(string exp){
	exp = suffixee(exp);
	return evaluer(exp);
}