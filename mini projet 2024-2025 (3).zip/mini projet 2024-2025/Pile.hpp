#include <string>
using namespace std;

class maillon
{
private:
    double info;
    maillon* suivant;
    friend class Pile;
    friend class expression;
public:
    maillon(double x);
    ~maillon();
};

class Pile
{
private:
    maillon * tete;
    int nbe;
    friend class expression;
public:
    Pile();
    ~Pile();

    void empiler(double x);
    double depiler();
    bool vide(); 

};



