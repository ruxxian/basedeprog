

class noeud
{
	char type ; //‘o’ pour opérateur et ‘f’ pour valeur.
	char ope ;
	double val ;
	noeud * fg, * fd ;
public:
	noeud(double v) : type('f'), val(v), fg(nullptr), fd(nullptr) {}
    noeud(char op, noeud* g, noeud* d) : type('o'), ope(op), fg(g), fd(d) {}
    ~noeud() {
        delete fg;
        delete fd;
    }
};

class Arbre
{
	noeud * racine;
public:
	Arbre();
	~Arbre();
	
};

class Pilenoeud
{
	noeud * tete;
	int nbe;
	//nous utilisons 
public:
	Pilenoeud() : tete(nullptr), nbe(0) {}

}