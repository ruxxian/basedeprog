#include "expression.hpp"
#include <iostream>
#include <string>
using namespace std;

int main()
{
    string test = "3.5 3.5 + 3 *";
    expression calc;
    cout << "calculer avec expression sufixée: " << calc.evaluer(test) << endl;
    test = "( 3.5 + 3.5 ) * 3";
    cout << calc.suffixee(test) << endl;
    cout << "calculer avec expression infixée: " << calc.evaluerinfixee(test) << endl;
    return 0;

}
