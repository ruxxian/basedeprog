#include <string>
using namespace std;

class cmaillon
{
private:
    char info;
    cmaillon* suivant;
    friend class cPile;
    friend class expression;
public:
    cmaillon(char c);
    ~cmaillon();
};

class cPile
{
private:
    cmaillon * tete;
    int nbe;
    friend class expression;
public:
    cPile();
    ~cPile();

    void empiler(char ch);
    char depiler();
    bool vide();
    char sommet();

};


