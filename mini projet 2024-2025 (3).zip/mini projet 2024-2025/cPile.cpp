#include "cPile.hpp"
#include <string> 
#include <iostream>

using namespace std;


cmaillon::cmaillon(char c){
    info = c;
    suivant = nullptr;
}

cmaillon::~cmaillon()
{
}

cPile::cPile(){
    tete = nullptr;
    nbe = 0;
}

cPile::~cPile(){
    if(tete!=NULL) delete tete;
}

void cPile::empiler(char c){
	cmaillon * p = new cmaillon(c);
	p->suivant = tete;
	tete = p;
	nbe++;
}

char cPile::depiler() {
    if (vide()) {
        // Stack is empty, throw an exception
        throw std::out_of_range("Cannot depile from empty stack.");
    } else {
        cmaillon *temp = tete;
        char retour = temp->info;
        tete = tete->suivant;
        delete temp;
      	nbe--;
        return retour;
    }
}

bool cPile::vide(){
    return(!(tete));
}

char cPile::sommet(){
	if(tete!=NULL){
        char ret = tete->info;
        return(ret);
    }
    return('\0');
}