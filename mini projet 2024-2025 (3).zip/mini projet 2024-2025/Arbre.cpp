#include "Arbre.hpp"
#include "expression.hpp"
#include ""
#include <string>
using namespace std;

Arbre::Arbre(){
	racine = NULL;
}

Arbre::~Arbre(){
	if(racine!=NULL)delete racine;
}

Arbre::Arbre(string infixe){
	expression calc;
	string sufixe =  calc.suffixee(infixe);
}
/*
Fonction infixeVersArbre(expressionInfixe):
    expressionSuffixe = convertirEnSuffixe(expressionInfixe)  # Utilise l'algorithme classique de conversion
    pile = nouvellePile()
    
    Pour chaque élément dans expressionSuffixe:
        Si élément est un opérande:
            nouveauNoeud = créerNoeud(élément)  # Crée un nœud avec l'opérande
            empiler(pile, nouveauNoeud)
        Sinon si élément est un opérateur:
            # Crée un nœud pour l'opérateur
            noeudOperateur = créerNoeud(élément)
            
            # Récupère les deux opérandes (d'abord droit puis gauche car dépilage)
            filsDroit = dépiler(pile)
            filsGauche = dépiler(pile)
            
            # Attache les fils au nœud opérateur
            noeudOperateur.gauche = filsGauche
            noeudOperateur.droit = filsDroit
            
            # Empile le nœud opérateur
            empiler(pile, noeudOperateur)
    
    # À la fin, la pile contient la racine de l'arbre
    racine = dépiler(pile)
    Retourner racine


*/