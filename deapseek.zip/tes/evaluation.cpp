#include "evaluation.hpp"
#include <iostream>
#include <sstream>
#include <cctype>
#include <cmath>
#include <cstring>

double evaluer_expression_suffixee(const std::string& expression) {
    Pile pile;
    std::istringstream iss(expression);
    std::string token;
    
    while (iss >> token) {
        if (isdigit(token[0])) {
            pile.empiler(stod(token));
        } else if (token.size() == 1 && strchr("+-*/^", token[0])) {
            if (pile.est_vide()) throw std::runtime_error("Expression invalide");
            double droite = pile.depiler();
            
            if (pile.est_vide()) throw std::runtime_error("Expression invalide");
            double gauche = pile.depiler();
            
            switch (token[0]) {
                case '+': pile.empiler(gauche + droite); break;
                case '-': pile.empiler(gauche - droite); break;
                case '*': pile.empiler(gauche * droite); break;
                case '/': 
                    if (droite == 0) throw std::runtime_error("Division par zéro");
                    pile.empiler(gauche / droite); 
                    break;
                case '^': pile.empiler(pow(gauche, droite)); break;
                default: throw std::runtime_error("Opérateur inconnu");
            }
        } else {
            throw std::runtime_error("Token invalide: " + token);
        }
    }
    
    if (pile.est_vide()) throw std::runtime_error("Expression vide");
    double resultat = pile.depiler();
    
    if (!pile.est_vide()) {
        throw std::runtime_error("Expression mal formée");
    }
    
    return resultat;
}
