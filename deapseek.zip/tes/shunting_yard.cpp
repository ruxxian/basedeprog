#include "shunting_yard.hpp"
#include <stack>
#include <sstream>
#include <cctype>
#include <cstring>

int precedence(char op) {
    static const std::map<char, int> prec = {
        {'^', 4},
        {'*', 3}, {'/', 3},
        {'+', 2}, {'-', 2}
    };
    auto it = prec.find(op);
    return it != prec.end() ? it->second : 0;
}

bool est_associatif_droite(char op) {
    return op == '^';
}

std::string infixe_vers_suffixe(const std::string& infixe) {
    std::stack<char> operateurs;
    std::string suffixe;
    std::istringstream iss(infixe);
    std::string token;
    
    while (iss >> token) {
        if (isdigit(token[0])) {
            suffixe += token + " ";
        } else if (token == "(") {
            operateurs.push('(');
        } else if (token == ")") {
            while (!operateurs.empty() && operateurs.top() != '(') {
                suffixe += std::string(1, operateurs.top()) + " ";
                operateurs.pop();
            }
            if (operateurs.empty()) {
                throw std::runtime_error("Parenthèses non équilibrées");
            }
            operateurs.pop();
        } else if (token.size() == 1 && strchr("+-*/^", token[0])) {
            char op = token[0];
            while (!operateurs.empty() && operateurs.top() != '(' &&
                   ((est_associatif_droite(op) && precedence(op) < precedence(operateurs.top())) ||
                    (!est_associatif_droite(op) && precedence(op) <= precedence(operateurs.top())))) {
                suffixe += std::string(1, operateurs.top()) + " ";
                operateurs.pop();
            }
            operateurs.push(op);
        } else {
            throw std::runtime_error("Token invalide: " + token);
        }
    }
    
    while (!operateurs.empty()) {
        if (operateurs.top() == '(') {
            throw std::runtime_error("Parenthèses non équilibrées");
        }
        suffixe += std::string(1, operateurs.top()) + " ";
        operateurs.pop();
    }
    
    if (!suffixe.empty() && suffixe.back() == ' ') {
        suffixe.pop_back();
    }
    
    return suffixe;
}
