#ifndef SHUNTING_YARD_HPP
#define SHUNTING_YARD_HPP

#include <string>
#include <map>

std::string infixe_vers_suffixe(const std::string& infixe);

#endif