#ifndef ARBRE_HPP
#define ARBRE_HPP

#include <iostream>
#include <string>

class Noeud {
public:
    char type;
    char ope;
    double val;
    Noeud* fg;
    Noeud* fd;
    
    Noeud(char t, char op = '\0', double v = 0.0, Noeud* left = nullptr, Noeud* right = nullptr);
};

class Arbre {
private:
    Noeud* racine;
    
    void supprimer_arbre(Noeud* n);
    Noeud* construire_arbre_suffixe(const std::string& suffixe);
    double evaluer_noeud(Noeud* n) const;
    void afficher_infixe_noeud(Noeud* n, std::ostream& os, bool parentheses) const;
    
public:
    Arbre();
    Arbre(const std::string& expression_infixe);
    ~Arbre();
    double evaluer() const;
    void afficher_infixe(std::ostream& os = std::cout) const;
};

#endif