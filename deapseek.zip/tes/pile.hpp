#ifndef PILE_HPP
#define PILE_HPP

#include <stdexcept>

class NoeudPile {
public:
    double valeur;
    NoeudPile* suivant;
    
    NoeudPile(double val, NoeudPile* suiv = nullptr) : valeur(val), suivant(suiv) {}
};

class Pile {
private:
    NoeudPile* sommet;
    
public:
    Pile();
    ~Pile();
    bool est_vide() const;
    void empiler(double valeur);
    double depiler();
    double voir_sommet() const;
};

#endif