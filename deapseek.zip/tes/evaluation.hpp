#ifndef EVALUATION_HPP
#define EVALUATION_HPP

#include <string>
#include "pile.hpp"

double evaluer_expression_suffixee(const std::string& expression);

#endif