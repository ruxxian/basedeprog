#include <iostream>
#include "evaluation.hpp"
#include "shunting_yard.hpp"
#include "arbre.hpp"

void tester_question1() {
    try {
        std::cout << "=== Question 1 ===" << std::endl;
        std::cout << "Evaluation de '3 4 +' : " << evaluer_expression_suffixee("3 4 +") << std::endl;
        std::cout << "Evaluation de '5 1 2 + 4 * + 3 -' : " 
                  << evaluer_expression_suffixee("5 1 2 + 4 * + 3 -") << std::endl;
    } catch (const std::exception& e) {
        std::cerr << "Erreur: " << e.what() << std::endl;
    }
}

void tester_question2() {
    try {
        std::cout << "\n=== Question 2 ===" << std::endl;
        std::cout << "Infixe: 3 + 4 * 5" << std::endl;
        std::cout << "Suffixe: " << infixe_vers_suffixe("3 + 4 * 5") << std::endl;
        
        std::cout << "Infixe: 3 * ( 4 + 5 )" << std::endl;
        std::cout << "Suffixe: " << infixe_vers_suffixe("3 * ( 4 + 5 )") << std::endl;
    } catch (const std::exception& e) {
        std::cerr << "Erreur: " << e.what() << std::endl;
    }
}

void tester_question3() {
    try {
        std::cout << "\n=== Question 3 ===" << std::endl;
        Arbre a1("3 + 4 * 5");
        std::cout << "Expression infixe: ";
        a1.afficher_infixe();
        std::cout << "\nEvaluation: " << a1.evaluer() << std::endl;
    } catch (const std::exception& e) {
        std::cerr << "Erreur: " << e.what() << std::endl;
    }
}

int main() {
    tester_question1();
    tester_question2();
    tester_question3();
    return 0;
}