#include "arbre.hpp"
#include "shunting_yard.hpp"
#include <stack>
#include <sstream>
#include <cmath>
#include <cstring>

Noeud::Noeud(char t, char op, double v, Noeud* left, Noeud* right)
    : type(t), ope(op), val(v), fg(left), fd(right) {}

Arbre::Arbre() : racine(nullptr) {}

Arbre::Arbre(const std::string& expression_infixe) {
    std::string suffixe = infixe_vers_suffixe(expression_infixe);
    racine = construire_arbre_suffixe(suffixe);
}

Arbre::~Arbre() {
    supprimer_arbre(racine);
}

void Arbre::supprimer_arbre(Noeud* n) {
    if (n) {
        supprimer_arbre(n->fg);
        supprimer_arbre(n->fd);
        delete n;
    }
}

Noeud* Arbre::construire_arbre_suffixe(const std::string& suffixe) {
    std::stack<Noeud*> pile;
    std::istringstream iss(suffixe);
    std::string token;
    
    while (iss >> token) {
        if (isdigit(token[0])) {
            pile.push(new Noeud('f', '\0', stod(token)));
        } else if (token.size() == 1 && strchr("+-*/^", token[0])) {
            if (pile.size() < 2) throw std::runtime_error("Expression invalide");
            
            Noeud* droite = pile.top(); pile.pop();
            Noeud* gauche = pile.top(); pile.pop();
            
            pile.push(new Noeud('o', token[0], 0.0, gauche, droite));
        } else {
            throw std::runtime_error("Token invalide: " + token);
        }
    }
    
    if (pile.size() != 1) throw std::runtime_error("Expression mal formée");
    return pile.top();
}

double Arbre::evaluer_noeud(Noeud* n) const {
    if (n->type == 'f') {
        return n->val;
    }
    
    double gauche = evaluer_noeud(n->fg);
    double droite = evaluer_noeud(n->fd);
    
    switch (n->ope) {
        case '+': return gauche + droite;
        case '-': return gauche - droite;
        case '*': return gauche * droite;
        case '/': 
            if (droite == 0) throw std::runtime_error("Division par zéro");
            return gauche / droite;
        case '^': return pow(gauche, droite);
        default: throw std::runtime_error("Opérateur inconnu");
    }
}

double Arbre::evaluer() const {
    if (!racine) throw std::runtime_error("Arbre vide");
    return evaluer_noeud(racine);
}

void Arbre::afficher_infixe_noeud(Noeud* n, std::ostream& os, bool parentheses) const {
    if (n->type == 'f') {
        os << n->val;
        return;
    }
    
    if (parentheses) os << "(";
    afficher_infixe_noeud(n->fg, os, true);
    os << " " << n->ope << " ";
    afficher_infixe_noeud(n->fd, os, true);
    if (parentheses) os << ")";
}

void Arbre::afficher_infixe(std::ostream& os) const {
    if (!racine) {
        os << "Arbre vide";
        return;
    }
    afficher_infixe_noeud(racine, os, false);
}
