#include "pile.hpp"

Pile::Pile() : sommet(nullptr) {}

Pile::~Pile() {
    while (!est_vide()) {
        depiler();
    }
}

bool Pile::est_vide() const {
    return sommet == nullptr;
}

void Pile::empiler(double valeur) {
    NoeudPile* nouveau = new NoeudPile(valeur, sommet);
    sommet = nouveau;
}

double Pile::depiler() {
    if (est_vide()) {
        throw std::runtime_error("Pile vide");
    }
    NoeudPile* temp = sommet;
    double valeur = temp->valeur;
    sommet = sommet->suivant;
    delete temp;
    return valeur;
}

double Pile::voir_sommet() const {
    if (est_vide()) {
        throw std::runtime_error("Pile vide");
    }
    return sommet->valeur;
}